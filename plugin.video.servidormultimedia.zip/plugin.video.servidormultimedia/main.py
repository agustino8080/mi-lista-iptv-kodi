import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib.request
from html.parser import HTMLParser

ADDON_ID = 'plugin.video.servidormultimedia'
ADDON = xbmcaddon.Addon(ADDON_ID)
BASE_URL = ADDON.getSetting('server_url') or 'http://15.235.51.60/'
HANDLE = int(sys.argv[1])

class ServerIndexParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_table = False
        self.in_row = False
        self.in_cell = False
        self.current_cell = ''
        self.items = []
        self.current_item = {}

    def handle_starttag(self, tag, attrs):
        if tag == 'table':
            self.in_table = True
        elif self.in_table and tag == 'tr':
            self.in_row = True
            self.current_item = {}
        elif self.in_row and tag == 'td':
            self.in_cell = True
            self.current_cell = ''

    def handle_data(self, data):
        if self.in_cell:
            self.current_cell += data.strip()

    def handle_endtag(self, tag):
        if tag == 'table':
            self.in_table = False
        elif self.in_table and tag == 'tr':
            self.in_row = False
            if len(self.current_item) == 5 and self.current_item['name'] not in ['Name', '[DIR]', '[ICO]']:
                self.items.append(self.current_item)
        elif self.in_row and tag == 'td':
            self.in_cell = False
            if len(self.current_item) == 0:
                self.current_item['type'] = self.current_cell
            elif len(self.current_item) == 1:
                self.current_item['name'] = self.current_cell
            elif len(self.current_item) == 2:
                self.current_item['modified'] = self.current_cell
            elif len(self.current_item) == 3:
                self.current_item['size'] = self.current_cell
            elif len(self.current_item) == 4:
                self.current_item['desc'] = self.current_cell

def list_items(url):
    try:
        response = urllib.request.urlopen(url)
        html = response.read().decode('utf-8')
        parser = ServerIndexParser()
        parser.feed(html)

        for item in parser.items:
            item_url = url + item['name']
            list_item = xbmcgui.ListItem(label=item['name'])

            if item['type'] == '[DIR]':
                list_item.setInfo('video', {'title': item['name'], 'plot': f'Carpeta modificada: {item["modified"]}'})
                list_item.setProperty('IsPlayable', 'false')
                xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=True)
            else:
                list_item.setInfo('video', {'title': item['name'], 'size': item['size'], 'plot': f'Archivo modificado: {item["modified"]}'})
                list_item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)

        xbmcplugin.endOfDirectory(HANDLE)

    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'No se pudo acceder al servidor: {str(e)}')

def play_item(url):
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)

if __name__ == '__main__':
    url = sys.argv[2] if len(sys.argv) > 2 else BASE_URL
    if url.endswith('/'):
        list_items(url)
    else:
        play_item(url)