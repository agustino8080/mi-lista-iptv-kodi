# -*- coding: utf-8 -*-
import sys
import urllib.request
import re
import json
import os

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

# Handles básicos
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = xbmc.translatePath(ADDON.getAddonInfo('path'))
PROFILE_PATH = xbmc.translatePath(ADDON.getAddonInfo('profile'))
HANDLE = int(sys.argv[1])

# Archivo para cache (opcional para no descargar siempre)
CACHE_FILE = os.path.join(PROFILE_PATH, 'canales_cache.json')

# ----------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------

def log(mensaje):
    xbmc.log(f"[{ADDON_NAME}] {mensaje}", xbmc.LOG_INFO)

def notificar(titulo, mensaje, icon=xbmcgui.NOTIFICATION_INFO, tiempo=3000):
    if ADDON.getSettingBool('mostrar_notificaciones'):
        xbmcgui.Dialog().notification(titulo, mensaje, icon=icon, time=tiempo)

# ----------------------------------------------------------------------
# Carga de listas M3U
# ----------------------------------------------------------------------

def obtener_urls_listas():
    urls = []
    for i in range(1, 9):
        url = ADDON.getSetting(f'url_{i}')
        if url:
            urls.append((f"Lista {i}", url))
    return urls

def descargar_m3u(nombre_lista, url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Kodi/20.0'})
        with urllib.request.urlopen(req) as resp:
            data = resp.read().decode('utf-8', errors='ignore')
        log(f"Descargada {nombre_lista}: {url}")
        return data
    except Exception as e:
        log(f"Error al descargar {nombre_lista} ({url}): {e}")
        return None

def parsear_m3u(nombre_lista, contenido):
    canales = []
    if not contenido:
        return canales

    lineas = contenido.splitlines()
    canal_actual = None

    for linea in lineas:
        linea = linea.strip()
        if linea.startswith('#EXTINF'):
            # Nombre
            match_nombre = re.search(r'#EXTINF:[^,]*,(.*)$', linea)
            nombre = match_nombre.group(1).strip() if match_nombre else 'Canal sin nombre'

            # group-title
            match_grupo = re.search(r'group-title="([^"]+)"', linea, re.IGNORECASE)
            grupo = match_grupo.group(1).strip() if match_grupo else 'Sin grupo'

            # tvg-logo
            match_logo = re.search(r'tvg-logo="([^"]+)"', linea, re.IGNORECASE)
            logo = match_logo.group(1).strip() if match_logo else ''

            # tvg-country
            match_pais = re.search(r'tvg-country="([^"]+)"', linea, re.IGNORECASE)
            pais = match_pais.group(1).strip() if match_pais else ''

            # tvg-language
            match_idioma = re.search(r'tvg-language="([^"]+)"', linea, re.IGNORECASE)
            idioma = match_idioma.group(1).strip() if match_idioma else ''

            canal_actual = {
                'nombre': nombre,
                'url': '',
                'lista': nombre_lista,
                'grupo': grupo,
                'pais': pais,
                'idioma': idioma,
                'logo': logo
            }

        elif linea.startswith('http') and canal_actual:
            canal_actual['url'] = linea
            canales.append(canal_actual)
            canal_actual = None

    return canales

def cargar_canales(force=False):
    # Cache para evitar descargar siempre
    if not force and os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            log("Cargados canales desde cache")
            return data
        except:
            pass

    urls_listas = obtener_urls_listas()
    todos_canales = []
    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, 'Descargando listas M3U...')

    total = len(urls_listas) if urls_listas else 1
    for idx, (nombre_lista, url) in enumerate(urls_listas, start=1):
        if dialog.iscanceled():
            break
        dialog.update(int(idx * 100 / total), f"{nombre_lista}", url)
        contenido = descargar_m3u(nombre_lista, url)
        canales = parsear_m3u(nombre_lista, contenido)
        todos_canales.extend(canales)

    dialog.close()
    max_canales = int(ADDON.getSetting('max_canales') or 500)
    todos_canales = todos_canales[:max_canales]

    # Guardar cache
    os.makedirs(PROFILE_PATH, exist_ok=True)
    try:
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(todos_canales, f, ensure_ascii=False)
    except Exception as e:
        log(f"No se pudo guardar cache: {e}")

    notificar('Listas cargadas', f'Se cargaron {len(todos_canales)} canales.')
    return todos_canales

# ----------------------------------------------------------------------
# Menús
# ----------------------------------------------------------------------

def mostrar_menu_principal():
    canales = cargar_canales()
    if not canales:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron canales.')
        return

    # 1) Listas
    item = xbmcgui.ListItem('Listas IPTV')
    url = f"{sys.argv[0]}?accion=listas"
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    # 2) Todos los canales
    item = xbmcgui.ListItem('Todos los canales')
    url = f"{sys.argv[0]}?accion=todos"
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    # 3) Grupos
    item = xbmcgui.ListItem('Grupos / Categorías')
    url = f"{sys.argv[0]}?accion=grupos"
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    # 4) Países
    item = xbmcgui.ListItem('Países')
    url = f"{sys.argv[0]}?accion=paises"
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    # 5) Idiomas
    item = xbmcgui.ListItem('Idiomas')
    url = f"{sys.argv[0]}?accion=idiomas"
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=True)

    # 6) Buscar
    item = xbmcgui.ListItem('Buscar')
    url = f"{sys.argv[0]}?accion=buscar"
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def listar_canales(canales):
    for canal in canales:
        li = xbmcgui.ListItem(canal['nombre'])
        li.setInfo('video', {
            'title': canal['nombre'],
            'genre': canal.get('grupo', ''),
            'country': canal.get('pais', ''),
            'language': canal.get('idioma', '')
        })
        if canal.get('logo'):
            li.setArt({'icon': canal['logo'], 'thumb': canal['logo']})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, canal['url'], li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def menu_listas():
    canales = cargar_canales()
    listas = sorted(set(c['lista'] for c in canales))
    for lista in listas:
        li = xbmcgui.ListItem(lista)
        url = f"{sys.argv[0]}?accion=por_lista&lista={lista}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def menu_por_lista(lista):
    canales = [c for c in cargar_canales() if c['lista'] == lista]
    listar_canales(canales)

def menu_grupos():
    canales = cargar_canales()
    grupos = sorted(set(c['grupo'] for c in canales if c.get('grupo')))
    for grupo in grupos:
        li = xbmcgui.ListItem(grupo)
        url = f"{sys.argv[0]}?accion=por_grupo&grupo={grupo}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def menu_por_grupo(grupo):
    canales = [c for c in cargar_canales() if c['grupo'] == grupo]
    listar_canales(canales)

def menu_paises():
    canales = cargar_canales()
    paises = sorted(set(c['pais'] for c in canales if c.get('pais')))
    for pais in paises:
        li = xbmcgui.ListItem(pais)
        url = f"{sys.argv[0]}?accion=por_pais&pais={pais}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def menu_por_pais(pais):
    canales = [c for c in cargar_canales() if c['pais'] == pais]
    listar_canales(canales)

def menu_idiomas():
    canales = cargar_canales()
    idiomas = sorted(set(c['idioma'] for c in canales if c.get('idioma')))
    for idioma in idiomas:
        li = xbmcgui.ListItem(idioma)
        url = f"{sys.argv[0]}?accion=por_idioma&idioma={idioma}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def menu_por_idioma(idioma):
    canales = [c for c in cargar_canales() if c['idioma'] == idioma]
    listar_canales(canales)

def accion_buscar():
    term = xbmcgui.Dialog().input('Buscar canal')
    if not term:
        return
    term_low = term.lower()
    canales = cargar_canales()
    filtrados = [
        c for c in canales
        if term_low in c['nombre'].lower()
        or term_low in c.get('grupo', '').lower()
        or term_low in c.get('pais', '').lower()
    ]
    listar_canales(filtrados)

# ----------------------------------------------------------------------
# Enrutador
# ----------------------------------------------------------------------

def obtener_params():
    from urllib.parse import parse_qs
    if len(sys.argv) < 3 or not sys.argv[2]:
        return {}
    return {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}

def router():
    params = obtener_params()
    accion = params.get('accion')

    if not accion:
        mostrar_menu_principal()
    elif accion == 'listas':
        menu_listas()
    elif accion == 'por_lista':
        menu_por_lista(params.get('lista', ''))
    elif accion == 'todos':
        listar_canales(cargar_canales())
    elif accion == 'grupos':
        menu_grupos()
    elif accion == 'por_grupo':
        menu_por_grupo(params.get('grupo', ''))
    elif accion == 'paises':
        menu_paises()
    elif accion == 'por_pais':
        menu_por_pais(params.get('pais', ''))
    elif accion == 'idiomas':
        menu_idiomas()
    elif accion == 'por_idioma':
        menu_por_idioma(params.get('idioma', ''))
    elif accion == 'buscar':
        accion_buscar()
    else:
        mostrar_menu_principal()

if __name__ == '__main__':
    router()
